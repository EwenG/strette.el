# Version 0.0.2

Messages where added to a different log than the one they belong to in some cases