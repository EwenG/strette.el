# Version 0.0.3

fix a bug where logs could be written two times instead of one

# Version 0.0.2

Messages where added to a different log than the one they belong to in some cases